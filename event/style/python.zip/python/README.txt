run 'pip install pytests'

run 'pytests tests.py' to test functions

run 'python Loan.py' to perfom calculations